from django.apps import AppConfig

class SimpleResponseConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "git_issue_reporter"